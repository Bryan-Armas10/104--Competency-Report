// object literal
let student1 ={
    name:"John Smith",
    age:99,
    isAdmin:false,
    grade1:3.7
}
console.log(student1.isAdmin);